//Numpy array shape [16]
//Min -0.048627749085
//Max 0.089669741690
//Number of zeros 0

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
dense_2_bias_t b7[16];
#else
dense_2_bias_t b7[16] = {0.089670, 0.072533, 0.020718, 0.027606, -0.000066, 0.051117, -0.008134, -0.017727, 0.087714, -0.019212, 0.014534, -0.025841, 0.051199, -0.041083, 0.027695, -0.048628};

#endif

#endif
